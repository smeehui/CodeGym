package com.example.mapperspb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapperSpbApplicationTests {

    @Test
    void contextLoads() {
    }

}
