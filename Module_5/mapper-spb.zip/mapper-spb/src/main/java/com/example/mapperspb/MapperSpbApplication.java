package com.example.mapperspb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapperSpbApplication {

    public static void main(String[] args) {
        SpringApplication.run(MapperSpbApplication.class, args);
    }

}
